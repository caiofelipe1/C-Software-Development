using Aula2402;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        List<Aluno> listaAlunos = new List<Aluno>();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Aluno aluno = new Aluno();
            aluno.id = int.Parse(txtCodigo.Text);
            aluno.nome = txtNome.Text;
            //aluno.RM = txtRM.Text; 
            aluno.curso = txtCurso.Text;

            listaAlunos.Add(aluno);

            txtCodigo.Text = string.Empty;
            txtCodigo.Text = "";

            MessageBox.Show("Aluno cadastrado com sucesso!", "Fiap");
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
