﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula2402
{
    public class Aluno
    {
        public int id {  get; set; }

        public string nome { get; set; }
        public string RM { get; }
         public string curso { get; set; }
         public string email { get; set; }
         public string telefone { get; set; }
    }
}
